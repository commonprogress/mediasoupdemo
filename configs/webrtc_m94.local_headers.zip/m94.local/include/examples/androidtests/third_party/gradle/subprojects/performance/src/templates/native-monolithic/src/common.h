
#ifndef COMMON_HEADER_${sourceIdx}_H
#define COMMON_HEADER_${sourceIdx}_H

// TODO: Actually do something in this common header

#endif // COMMON_HEADER_${sourceIdx}_H