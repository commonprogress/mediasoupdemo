#define __STDC_LIMIT_MACROS
#import <stdint.h>
#import <Foundation/Foundation.h>

@interface Greeter : NSObject
    - (void)sayHello;
@end
