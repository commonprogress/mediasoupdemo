int plus(int a, int b);
int minus(int a, int b);
