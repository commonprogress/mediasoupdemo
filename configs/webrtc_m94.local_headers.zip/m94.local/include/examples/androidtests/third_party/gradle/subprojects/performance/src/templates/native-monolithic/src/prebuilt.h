
#ifndef PREBUILT_HEADER_${sourceIdx+offset}_H
#define PREBUILT_HEADER_${sourceIdx+offset}_H

// TODO: Actually do something in this header

#endif // PREBUILT_HEADER_${sourceIdx+offset}_H